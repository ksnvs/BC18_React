import { Modal, Button } from "antd";
import React, { Component } from "react";

export default class ModelGioHang extends Component {
  state = {
    isModalVisible: false,
  };
  showModal = () => {
    // setIsModalVisible(true);
    this.setState({ isModalVisible: true });
  };

  handleOk = () => {
    // setIsModalVisible(false);
    this.setState({ isModalVisible: false });
  };

  handleCancel = () => {
    // setIsModalVisible(false);
    this.setState({ isModalVisible: false });
  };
  renderSanPham = () => {
    console.log(this.props.gioHang);
    return this.props.gioHang.map((sp) => {
      return (
        <tr>
          <td>{sp.id}</td>
          <td>
            <img src={sp.thumbnail_url} />
          </td>
          <td>{sp.name}</td>
          <td>{sp.soluong}</td>
        </tr>
      );
    });
  };
  render() {
    return (
      <>
        <Button type="primary" onClick={this.showModal}>
          Giỏ hàng
        </Button>
        <Modal
          title="Giỏ hàng"
          visible={this.state.isModalVisible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          width={1000}
        >
          <div>
            <table className="table">
              <thead>
                <tr>
                  <th>Mã sản phẩn</th>
                  <th>Hình</th>
                  <th>Tên</th>
                  <th>Số lượng</th>
                  <th>Đơn giá</th>
                  <th>Thành tiền</th>
                </tr>
              </thead>
              <tbody>{this.renderSanPham()}</tbody>
            </table>
          </div>
        </Modal>
      </>
    );
  }
}
